# 0) 준비하기

1. 파이썬이 설치돼 있다면, 터미널/명령 프롬프트에서:

```bash
pip install pygame
```

2. 폴더를 하나 만들고 `main.py` 파일을 생성해요. 이후 코드는 전부 `main.py`에 붙여넣고 실행(▶)하면 됩니다.

---

# 3.4 pygame 기본 — 창 열기 & 게임 루프

아래 코드를 붙여넣고 실행해 보세요. 까만 창이 켜졌다가 X를 누르면 종료되면 성공!

```python
import pygame

# 1) pygame 시작
pygame.init()

# 2) 화면(창) 크기와 제목
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pygame 기본")

# 3) 시계(FPS 조절용)
clock = pygame.time.Clock()

running = True
while running:
    # 4) 이벤트 처리(닫기 버튼 등)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # 5) 화면 색 칠하기 (검정)
    screen.fill((0, 0, 0))

    # 6) 화면 업데이트
    pygame.display.flip()

    # 7) FPS 60으로 제한
    clock.tick(60)

pygame.quit()
```

✔ 체크포인트: 까만 창이 뜨고, 부드럽게 유지되다가 닫히면 OK.

---

# 3.5 선, 도형, 글자 그리기

이번엔 화면에 도형과 글자를 그려볼게요. (한글 폰트는 컴퓨터마다 달라서 **윈도우=‘malgungothic’**, 맥=‘AppleGothic’, 리눅스=‘NanumGothic’ 같은 이름을 써야 해요. 그냥 영어로 먼저 해보고, 한글이 □로 나오면 폰트 이름을 바꿔보세요.)

```python
import pygame

pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("그리기 연습")
clock = pygame.time.Clock()

# 색상 정의(빨, 초, 파, 흰, 회)
RED   = (255,  0,  0)
GREEN = (  0,255,  0)
BLUE  = (  0,  0,255)
WHITE = (255,255,255)
GRAY  = (100,100,100)

# 폰트 준비 (영어 OK / 한글은 폰트 이름 필요)
# font = pygame.font.SysFont("malgungothic", 32)  # 윈도우 한글
font = pygame.font.SysFont(None, 32)              # 기본(영어권 안정)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((20, 20, 20))  # 어두운 회색 배경

    # 1) 선 그리기(시작점, 끝점, 색, 두께)
    pygame.draw.line(screen, RED,   (50, 50),  (200, 50),  5)
    pygame.draw.line(screen, GREEN, (50, 80),  (200, 130), 3)

    # 2) 사각형(왼쪽위x,y, 가로, 세로) / 테두리만 그릴 수도 있음
    rect = pygame.Rect(300, 40, 150, 100)
    pygame.draw.rect(screen, BLUE, rect, border_radius=10)      # 채우기
    pygame.draw.rect(screen, WHITE, rect, 3, border_radius=10)  # 테두리

    # 3) 원(중심x,y, 반지름)
    pygame.draw.circle(screen, (255, 200, 0), (150, 250), 40)

    # 4) 다각형(점 목록)
    points = [(450, 200), (500, 250), (470, 300), (420, 270)]
    pygame.draw.polygon(screen, (180, 50, 200), points)

    # 5) 글자 그리기
    text_surface = font.render("Drawing Shapes!", True, WHITE)
    screen.blit(text_surface, (50, 350))
    # 한글(폰트 설정했다면)
    # text_kor = font.render("선/도형/글자 그리기", True, WHITE)
    # screen.blit(text_kor, (50, 390))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
```

✔ 체크포인트: 선, 사각형, 원, 다각형, 글자가 보이면 OK.

---

# 3.6 공놀이 하기 — 공 튕기기 + 패들로 받기(미니 게임)

이제 진짜 게임!
**목표:** 공이 화면 가장자리에서 튕기고, 아래쪽 패들(막대기)을 ←/→ 키로 움직여 공을 받아 점수를 올리자.
공이 바닥으로 떨어지면 게임오버. 스페이스로 시작, R로 재시작.

```python
import pygame
import random

# --- 초기 설정 ---
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("공놀이 하기 (클래스 없이)")
clock = pygame.time.Clock()

# 색상
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
YELLOW = (255, 220, 0)
CYAN = (0, 200, 255)

# 폰트 (한글 쓰려면 폰트 이름 지정)
# font = pygame.font.SysFont("malgungothic", 36)  # 윈도우
font = pygame.font.SysFont(None, 36)              # 기본(영어권 안정)

# --- 게임 변수 ---
# 패들
paddle_w, paddle_h = 120, 16
paddle_x = (WIDTH - paddle_w) // 2
paddle_y = HEIGHT - 50
paddle_speed = 8

# 공
ball_x, ball_y = WIDTH // 2, HEIGHT // 2
ball_r = 10
ball_dx, ball_dy = random.choice([-4, 4]), -4  # 시작 방향 랜덤(좌/우)

# 점수 & 상태
score = 0
game_state = "START"  # "START" -> "PLAYING" -> "GAMEOVER"

def reset_game():
    global paddle_x, score, ball_x, ball_y, ball_dx, ball_dy, game_state
    paddle_x = (WIDTH - paddle_w) // 2
    score = 0
    ball_x, ball_y = WIDTH // 2, HEIGHT // 2
    ball_dx, ball_dy = random.choice([-4, 4]), -4
    game_state = "PLAYING"

running = True
while running:
    # --- 이벤트 처리 ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()

    # --- 상태별 로직 ---
    if game_state == "START":
        if keys[pygame.K_SPACE]:
            reset_game()

    elif game_state == "PLAYING":
        # 패들 이동
        if keys[pygame.K_LEFT]:
            paddle_x -= paddle_speed
        if keys[pygame.K_RIGHT]:
            paddle_x += paddle_speed
        # 화면 밖으로 못 나가게
        if paddle_x < 0:
            paddle_x = 0
        if paddle_x > WIDTH - paddle_w:
            paddle_x = WIDTH - paddle_w

        # 공 이동
        ball_x += ball_dx
        ball_y += ball_dy

        # 벽 충돌(좌우)
        if ball_x - ball_r <= 0 or ball_x + ball_r >= WIDTH:
            ball_dx *= -1
        # 천장 충돌(위)
        if ball_y - ball_r <= 0:
            ball_dy *= -1

        # 패들과 충돌(아래쪽에서만)
        paddle_rect = pygame.Rect(paddle_x, paddle_y, paddle_w, paddle_h)
        # 공이 패들 높이까지 내려왔고, x가 패들 범위 안이면 튕기기
        if (ball_y + ball_r >= paddle_y and
            paddle_x <= ball_x <= paddle_x + paddle_w and
            ball_dy > 0):
            ball_dy *= -1
            score += 1

        # 바닥으로 떨어짐 -> 게임오버
        if ball_y - ball_r > HEIGHT:
            game_state = "GAMEOVER"

    elif game_state == "GAMEOVER":
        if keys[pygame.K_r]:
            reset_game()

    # --- 그리기 ---
    screen.fill((18, 18, 18))

    # 패들
    pygame.draw.rect(screen, CYAN, (paddle_x, paddle_y, paddle_w, paddle_h), border_radius=8)

    # 공
    pygame.draw.circle(screen, YELLOW, (int(ball_x), int(ball_y)), ball_r)

    # 상단 점수
    score_surf = font.render(f"Score: {score}", True, WHITE)
    screen.blit(score_surf, (20, 15))

    # 상태 안내 텍스트
    if game_state == "START":
        t1 = font.render("SPACE 로 시작!", True, WHITE)
        t2 = font.render("← → 로 패들을 움직여 공을 받아요.", True, WHITE)
        screen.blit(t1, (WIDTH//2 - t1.get_width()//2, HEIGHT//2 - 40))
        screen.blit(t2, (WIDTH//2 - t2.get_width()//2, HEIGHT//2 + 10))

    if game_state == "GAMEOVER":
        over = font.render("GAME OVER", True, WHITE)
        tip  = font.render("R 키로 다시 시작", True, WHITE)
        screen.blit(over, (WIDTH//2 - over.get_width()//2, HEIGHT//2 - 40))
        screen.blit(tip,  (WIDTH//2 - tip.get_width()//2, HEIGHT//2 + 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
```

✔ 체크포인트

* 스페이스 누르면 시작, ←/→로 패들 이동
* 공이 벽/천장에 튕김, 패들에 맞으면 점수 +1
* 바닥으로 떨어지면 GAME OVER, R로 재시작

---

## 추가 미션(선택)

* **난이도 상승:** 점수가 3, 6, 9… 될 때마다 공 속도를 살짝씩 올리기
* **아이템:** 위에서 내려오는 아이템(사각형)을 받아서 패들 길이 잠시 늘리기
* **사운드:** 충돌 시 효과음 재생 (`pygame.mixer.Sound`)
* **여러 공:** 일정 점수에 도달하면 공 하나 더 소환

예) 속도 살짝 올리기 힌트

```python
# 패들에 맞았을 때
ball_dy *= -1
score += 1
if score % 3 == 0:
    # 속도 조금 증가(부호 유지)
    ball_dx += 1 if ball_dx > 0 else -1
    ball_dy += 1 if ball_dy > 0 else -1
```

---

## 수업/학습 포인트 정리

* **3.4 기본:** 게임 루프(이벤트 처리 → 화면 그리기 → 업데이트 → FPS)
* **3.5 그리기:** `pygame.draw` 로 선/도형, `font.render` 로 텍스트
* **3.6 공놀이:** 위치/속도 변수로 “움직임”, 경계 충돌 판정, `Rect`와 좌표 비교로 “충돌”, 키 입력 처리



---




# 3.7 이미지 사용 — 불러오기 · 변환 · 배치

### 3.7-1) 에셋 폴더 만들기

* 작업 폴더 안에 **assets** 폴더를 만들고, 아래 파일을 넣으세요.

  * `assets/paddle.png` (가로 160px 정도)
  * `assets/ball.png`   (정사각형 64~96px, 배경 투명 권장)
  * `assets/bg.jpg` 또는 `assets/bg.png` (배경, 선택)

> PNG 투명도는 `convert_alpha()`로, JPG는 `convert()`로 로딩하면 성능이 좋아집니다.

### 3.7-2) 이미지 불러오기 (따라쓰기)

아래의 빈칸을 채워서 이미지가 화면에 보이게 하세요.

```python
import pygame, os
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()

ASSETS = "assets"
# 1) 이미지 로딩
paddle_img = pygame.image.load(os.path.join(ASSETS, "paddle.png")).____()   # 투명 포함
ball_img   = pygame.image.load(os.path.join(ASSETS, "ball.png")).____()     # 투명 포함
# (선택) 배경
# bg_img  = pygame.image.load(os.path.join(ASSETS, "bg.jpg")).convert()

# 2) 크기 조정(필요 시)
paddle_img = pygame.transform.scale(paddle_img, (160, 32))
ball_img   = pygame.transform.scale(ball_img, (64, 64))

# 3) 위치(Rect)
paddle_rect = paddle_img.get_rect(midbottom=(WIDTH//2, HEIGHT-40))
ball_rect   = ball_img.get_rect(center=(WIDTH//2, HEIGHT//2))

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    screen.fill((18,18,18))
    # if bg_img: screen.blit(bg_img, (0,0))

    screen.blit(paddle_img, paddle_rect)
    screen.blit(ball_img, ball_rect)

    pygame.display.flip()
    clock.tick(60)
pygame.quit()
```

✔ 체크: `paddle.png`와 `ball.png`가 보이면 성공.

### 3.7-3) 회전/스케일/뒤집기 연습

* [ ] 공을 매 프레임 `angle += 3` 해서 **회전**시키기
* [ ] `pygame.transform.rotozoom(image, angle, scale)` 로 부드럽게 회전/확대
* [ ] `pygame.transform.flip(image, True, False)` 로 좌우 뒤집기

힌트

```python
angle = 0
# 그리기 직전
rot = pygame.transform.rotozoom(ball_img, angle, 1.0)
rot_rect = rot.get_rect(center=ball_rect.center)
screen.blit(rot, rot_rect)
angle = (angle + 3) % 360
```

### 3.7-4) OX 퀴즈

* [ ] O/X: JPG 이미지는 `convert_alpha()`로 로드해야 투명 배경이 제대로 보인다.
* [ ] O/X: `image.get_rect()`는 이미지 크기에 맞는 사각형을 만들어 준다.

> 정답: JPG는 투명 없음 → `convert()`가 맞음.

---

# E. 3.8 키보드 조작 — 이동과 액션

### 3.8-1) 두 방식 비교

* **즉시 반응**: `KEYDOWN/KEYUP` 이벤트 → 한 번 눌렀을 때 행동(점프/발사 등)
* **연속 이동**: `pygame.key.get_pressed()` → 누르는 동안 계속 이동(←/→/WASD)

### 3.8-2) 연속 이동 구현 (따라쓰기)

아래 빈칸을 채워 패들이 ←/→ 로 움직이게 하세요.

```python
speed = 8
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        # (선택) 스페이스를 눌렀을 때 효과음/색 바꾸기 같은 1회성 액션
        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            print("SPACE!")

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        paddle_rect.x -= ____
    if keys[pygame.K_RIGHT]:
        paddle_rect.x += ____

    # 경계 체크(화면 밖 금지)
    if paddle_rect.left < 0:
        paddle_rect.left = 0
    if paddle_rect.right > WIDTH:
        paddle_rect.right = WIDTH

    screen.fill((25,25,25))
    screen.blit(paddle_img, paddle_rect)
    pygame.display.flip()
    clock.tick(60)
```

### 3.8-3) 미션

* [ ] ↑/↓도 추가해서 네 방향 이동 만들기
* [ ] **대시**: SHIFT가 눌린 동안 속도를 1.5배로 (힌트: `keys[pygame.K_LSHIFT]`)
* [ ] **경계 이펙트**: 화면 가장자리에 닿으면 잠깐 하얗게 깜빡이기

### 3.8-4) 객관식

1. `KEYDOWN`과 `get_pressed()`의 차이는? 가장 알맞은 것 하나.

   * (A) 둘 다 같은 기능 (B) `KEYDOWN`은 **한 번 눌림 감지**, `get_pressed`는 **누르는 중** 상태 확인 (C) 반대 의미 (D) 사운드용

---

# 3.9 마우스 조작 — 위치, 클릭, 드래그

### 3.9-1) 마우스 기초

* 현재 좌표: `mx, my = pygame.mouse.get_pos()`
* 버튼 상태: `btns = pygame.mouse.get_pressed()` (왼/가운데/오른쪽)
* 이벤트: `MOUSEBUTTONDOWN`, `MOUSEBUTTONUP`, `MOUSEMOTION`

### 3.9-2) 패들 드래그 이동 (따라쓰기)

패들을 **클릭해서 잡고 드래그**로 옮기기. (클래스 없이 상태변수 사용)

```python
dragging = False
offset_x = 0

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if paddle_rect.collidepoint(event.pos):
                dragging = True
                offset_x = paddle_rect.x - event.pos[0]
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            dragging = False
        elif event.type == pygame.MOUSEMOTION and dragging:
            paddle_rect.x = event.pos[0] + offset_x
            # 경계 고정
            if paddle_rect.left < 0: paddle_rect.left = 0
            if paddle_rect.right > WIDTH: paddle_rect.right = WIDTH

    screen.fill((30,30,30))
    screen.blit(paddle_img, paddle_rect)
    pygame.display.flip()
    clock.tick(60)
```

### 3.9-3) 미니게임 합치기 — "이미지 패들 & 공"

키보드(←/→)와 마우스 드래그 **둘 다**로 패들을 움직이고, 공 이미지는 벽/천장/패들에 튕기게 만드세요.

```python
import pygame, os, random
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
ASSETS = "assets"

# 이미지 로딩
paddle_img = pygame.image.load(os.path.join(ASSETS, "paddle.png")).convert_alpha()
ball_img   = pygame.image.load(os.path.join(ASSETS, "ball.png")).convert_alpha()
paddle_img = pygame.transform.scale(paddle_img, (160, 32))
ball_img   = pygame.transform.scale(ball_img, (64, 64))

paddle_rect = paddle_img.get_rect(midbottom=(WIDTH//2, HEIGHT-40))
ball_rect   = ball_img.get_rect(center=(WIDTH//2, HEIGHT//2))

font = pygame.font.SysFont(None, 32)
score = 0
ball_dx, ball_dy = random.choice([-4,4]), -4
angle = 0

# 마우스 드래그 상태
dragging = False
offset_x = 0

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN and event.key == pygame.K_r:
            # 재시작
            paddle_rect.midbottom = (WIDTH//2, HEIGHT-40)
            ball_rect.center = (WIDTH//2, HEIGHT//2)
            ball_dx, ball_dy = random.choice([-4,4]), -4
            score = 0
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if paddle_rect.collidepoint(event.pos):
                dragging = True
                offset_x = paddle_rect.x - event.pos[0]
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            dragging = False
        elif event.type == pygame.MOUSEMOTION and dragging:
            paddle_rect.x = event.pos[0] + offset_x

    # 키 연속 입력(←/→)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:  paddle_rect.x -= 8
    if keys[pygame.K_RIGHT]: paddle_rect.x += 8

    # 경계
    if paddle_rect.left < 0: paddle_rect.left = 0
    if paddle_rect.right > WIDTH: paddle_rect.right = WIDTH

    # 공 이동
    ball_rect.x += ball_dx
    ball_rect.y += ball_dy

    # 벽/천장 충돌
    if ball_rect.left <= 0 or ball_rect.right >= WIDTH:
        ball_dx *= -1
    if ball_rect.top <= 0:
        ball_dy *= -1

    # 패들 충돌 (아래에서 올라오지 않게)
    if ball_rect.bottom >= paddle_rect.top and ball_rect.centerx in range(paddle_rect.left, paddle_rect.right) and ball_dy > 0:
        ball_dy *= -1
        score += 1

    # 바닥으로 떨어지면 중앙으로 복귀
    if ball_rect.top > HEIGHT:
        ball_rect.center = (WIDTH//2, HEIGHT//2)
        ball_dx, ball_dy = random.choice([-4,4]), -4
        score = 0

    # 그리기
    screen.fill((16,16,20))
    # 회전 공
    angle = (angle + 4) % 360
    rot = pygame.transform.rotozoom(ball_img, angle, 1.0)
    rot_rect = rot.get_rect(center=ball_rect.center)

    screen.blit(rot, rot_rect)
    screen.blit(paddle_img, paddle_rect)

    txt = font.render(f"Score: {score}  (R: 리셋)", True, (255,255,255))
    screen.blit(txt, (20, 15))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
```

### 3.9-4) 디버깅 퀴즈

다음 중 버그인 것을 모두 고르세요.

1. `paddle_rect.centerx in range(paddle_rect.left, paddle_rect.right)` 로 충돌을 검사한다.
2. `convert_alpha()` 없이 PNG를 로드했다.
3. `MOUSEMOTION`에서 `dragging` 체크 없이 매번 패들 위치를 바꾼다.

> 해설 예시: (1) 범위 끝이 포함되지 않아 가장자리가 누락될 수 있음 → `<= <` 비교가 더 명확. (2) 투명 PNG는 `convert_alpha()` 권장. (3) 불필요한 흔들림/점프 발생.

---

## 종합 자기점검

* [ ] 이미지가 보이고, 크기 조정/회전/뒤집기가 된다
* [ ] 키보드로 연속 이동이 되고, SPACE 같은 1회성 액션도 처리할 수 있다
* [ ] 마우스로 드래그 이동이 되고, 클릭/업/모션 이벤트를 구분할 수 있다
* [ ] 이미지 패들 & 공 미니게임이 동작한다 (리셋 포함)

> 필요하면 동일 형식의 **정답지(빈칸 채움/퀴즈/디버깅 해설)**를 추가로 제공해 드릴 수 있어요.

---

## 3.10 음악 및 사운드 사용 — 배경음악(BGM)과 효과음(SFX)

### 3.10-1) 핵심 개념 요약

* **배경음악**: `pygame.mixer.music` (한 번에 1개만 재생, 길고 반복되는 음악에 적합)
* **효과음**: `pygame.mixer.Sound` (여러 개를 겹쳐 재생 가능, 짧은 효과음에 적합)
* **권장 포맷**: BGM → OGG, SFX → WAV (지연 적고 호환성 좋음)
* **볼륨 범위**: `0.0 ~ 1.0` (작을수록 조용)

> 폴더 준비: `assets/bgm.ogg`, `assets/bounce.wav`, `assets/gameover.wav`

### 3.10-2) BGM 재생 (빈칸 채우기)

아래 빈칸(____)을 채워 배경음악이 **무한 반복**으로 재생되게 하세요.

```python
import pygame, os
pygame.init()
ASSETS = "assets"

# (1) BGM 로드
pygame.mixer.music.load(os.path.join(ASSETS, "bgm.ogg"))
# (2) 볼륨 40%
pygame.mixer.music.set_volume(0.4)
# (3) 재생: 무한 반복
pygame.mixer.music.play(____)   # 힌트: -1 이면 무한 반복
```

* [ ] 실행 시 자연스럽게 음악이 계속 재생된다.

> 팁: 음악을 끄려면 `pygame.mixer.music.stop()` 또는 부드럽게 `pygame.mixer.music.fadeout(ms)`.

### 3.10-3) 효과음(SFX) 재생 (빈칸 채우기)

충돌 시 ‘툭’ 소리가 나도록 하세요.

```python
# 로드(초기화 구간)
bounce_snd   = pygame.mixer.Sound(os.path.join(ASSETS, "bounce.wav"))
bounce_snd.set_volume(0.6)

gameover_snd = pygame.mixer.Sound(os.path.join(ASSETS, "gameover.wav"))

# 충돌이 일어났을 때(예: 패들에 맞음)
# ... 충돌 판정 직후
bounce_snd.____()   # 힌트: 재생하는 메서드

# 게임오버가 되었을 때
# ... GAME OVER 상태 진입 시
pygame.mixer.music.fadeout(400)
gameover_snd.____()
```

* [ ] 패들에 공이 맞으면 ‘툭’ 소리가 난다.
* [ ] 게임오버 시 배경음이 페이드아웃되고 ‘삐-’ 같은 효과음이 난다.

### 3.10-4) 음소거 토글(M 키) 추가 (개념→실습)

개념: **음소거**는 음악·효과음 볼륨을 0으로 바꾸거나, 음악만 끄는 방식으로 구현할 수 있어요.

```python
muted = False
# 이벤트 루프에서
if event.type == pygame.KEYDOWN and event.key == pygame.K_m:
    muted = not muted
    # 음악 볼륨만 토글 (효과음은 유지해도 됨)
    pygame.mixer.music.set_volume(0.0 if muted else 0.4)
```

실습(빈칸): 아래 코드에서 음소거 토글의 **반대 동작**(효과음 전체 음량)을 추가해 보세요.

```python
# 전역 변수를 추가한다고 가정
sfx_volume = 0.6

if event.type == pygame.KEYDOWN and event.key == pygame.K_m:
    muted = not muted
    pygame.mixer.music.set_volume(0.0 if muted else 0.4)
    # TODO: 효과음 볼륨도 함께 토글 (빈칸)
    sfx_volume = ____ if muted else ____
    bounce_snd.set_volume(sfx_volume)
    gameover_snd.set_volume(sfx_volume)
```

### 3.10-5) 통합 미니게임(이미지+키보드+마우스+사운드)

아래 코드는 **빈칸이 포함된 통합 예시**입니다. 위 섹션(3.7~3.9)의 코드를 이미 만들었다고 가정하고, 사운드 부분을 중심으로 빈칸을 완성하세요.

```python
import pygame, os, random
pygame.init()
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
ASSETS = "assets"

# 이미지
paddle_img = pygame.image.load(os.path.join(ASSETS, "paddle.png")).convert_alpha()
ball_img   = pygame.image.load(os.path.join(ASSETS, "ball.png")).convert_alpha()
paddle_img = pygame.transform.scale(paddle_img, (160, 32))
ball_img   = pygame.transform.scale(ball_img, (64, 64))

paddle_rect = paddle_img.get_rect(midbottom=(WIDTH//2, HEIGHT-40))
ball_rect   = ball_img.get_rect(center=(WIDTH//2, HEIGHT//2))

# 폰트/점수/상태
font = pygame.font.SysFont(None, 32)
score = 0
ball_dx, ball_dy = random.choice([-4,4]), -4
angle = 0

# 마우스 드래그 상태
dragging = False
offset_x = 0

# ===== 사운드: BGM & SFX =====
pygame.mixer.music.load(os.path.join(ASSETS, "bgm.ogg"))
pygame.mixer.music.set_volume(0.4)
pygame.mixer.music.play(____)   # (1) 무한 반복

bounce_snd   = pygame.mixer.Sound(os.path.join(ASSETS, "bounce.wav"))
gameover_snd = pygame.mixer.Sound(os.path.join(ASSETS, "gameover.wav"))
sfx_volume = 0.6
bounce_snd.set_volume(sfx_volume)
gameover_snd.set_volume(sfx_volume)
muted = False

running = True
game_over = False
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:
                # 재시작
                paddle_rect.midbottom = (WIDTH//2, HEIGHT-40)
                ball_rect.center = (WIDTH//2, HEIGHT//2)
                ball_dx, ball_dy = random.choice([-4,4]), -4
                score = 0
                game_over = False
                pygame.mixer.music.play(____)  # (2) 재시작 시 다시 배경음
            elif event.key == pygame.K_m:
                muted = not muted
                pygame.mixer.music.set_volume(0.0 if muted else 0.4)
                sfx_volume = (____ if muted else ____)  # (3) 효과음 볼륨 토글
                bounce_snd.set_volume(sfx_volume)
                gameover_snd.set_volume(sfx_volume)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if paddle_rect.collidepoint(event.pos):
                dragging = True
                offset_x = paddle_rect.x - event.pos[0]
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            dragging = False
        elif event.type == pygame.MOUSEMOTION and dragging:
            paddle_rect.x = event.pos[0] + offset_x

    # 키 연속 입력
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:  paddle_rect.x -= 8
    if keys[pygame.K_RIGHT]: paddle_rect.x += 8

    # 경계
    if paddle_rect.left < 0: paddle_rect.left = 0
    if paddle_rect.right > WIDTH: paddle_rect.right = WIDTH

    # 공 이동 (게임오버 아니면)
    if not game_over:
        ball_rect.x += ball_dx
        ball_rect.y += ball_dy

        # 벽/천장 충돌
        if ball_rect.left <= 0 or ball_rect.right >= WIDTH:
            ball_dx *= -1
            # (선택) 벽 충돌에도 소리
            # bounce_snd.play()
        if ball_rect.top <= 0:
            ball_dy *= -1

        # 패들 충돌
        if ball_rect.bottom >= paddle_rect.top and paddle_rect.left <= ball_rect.centerx <= paddle_rect.right and ball_dy > 0:
            ball_dy *= -1
            score += 1
            bounce_snd.____()  # (4) 패들 맞으면 효과음

        # 바닥으로 떨어짐 → 게임오버
        if ball_rect.top > HEIGHT:
            game_over = True
            pygame.mixer.music.fadeout(400)
            gameover_snd.____()  # (5) 게임오버 효과음

    # 그리기
    screen.fill((16,16,20))
    angle = (angle + 4) % 360
    rot = pygame.transform.rotozoom(ball_img, angle, 1.0)
    rot_rect = rot.get_rect(center=ball_rect.center)
    screen.blit(rot, rot_rect)
    screen.blit(paddle_img, paddle_rect)

    txt = font.render(f"Score: {score}  (R: 리셋, M: 음소거)", True, (255,255,255))
    screen.blit(txt, (20, 15))

    if game_over:
        over = font.render("GAME OVER", True, (255,255,255))
        screen.blit(over, (WIDTH//2 - over.get_width()//2, HEIGHT//2 - 20))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
```

### 3.10-6) OX & 객관식 퀴즈

1. O/X: `pygame.mixer.music`는 동시에 여러 개의 음악을 겹쳐 재생할 수 있다.
2. O/X: `Sound`는 여러 개 겹쳐 재생이 가능하다.
3. (객관식) `pygame.mixer.music.play(-1)`의 의미는?

   * (A) 1번만 재생 (B) 무한 반복 (C) 1초 후 재생 (D) 일시정지

> 정답 예시: 1) X, 2) O, 3) (B)

### 3.10-7) 디버깅 체크리스트

* 소리가 안 나면:

  * [ ] 파일 경로/이름이 맞는지 (`assets/…`) 확인
  * [ ] 볼륨이 0인지 확인 (`set_volume`)
  * [ ] OS 별 코덱 문제일 수 있음 → WAV/OGG로 변경 시도
  * [ ] 이어폰/스피커 출력 장치 확인

---

## 종합 과제(선택)

* [ ] 점수가 일정 이상이 되면 **레벨업 효과음** 추가
* [ ] 특정 점수마다 BGM 볼륨을 조금씩 올리거나 교체(페이드아웃→새 BGM 페이드인)
* [ ] 충돌 위치에 따라 **피치**가 다른 bounce 소리 재생 (예: 여러 WAV 파일 준비)

